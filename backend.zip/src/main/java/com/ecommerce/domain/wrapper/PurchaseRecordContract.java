package com.ecommerce.domain.wrapper;

/**
 * TODO Sub PJT Ⅲ 과제 3
 * PurchaseRecord Contract's Wrapper Class를 생성하여 코드를 대체한다.
 */

public class PurchaseRecordContract {

}