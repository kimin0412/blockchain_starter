package com.ecommerce.domain.wrapper;

/**
 * TODO Sub PJT Ⅱ 과제 3
 * ERC-20 Token's Wrapper Class를 생성하여 코드를 대체한다.
 */

public class CashContract {

}
