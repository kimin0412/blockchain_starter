package com.ecommerce.application;

public interface ICashContractService {
    int getBalance(String eoa);
}
